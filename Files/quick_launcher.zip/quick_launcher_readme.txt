Quick Launcher 
Created by Ron Goode aka Mr.Rocket 2026


Quick Launcher is just what it says it is. No bells, no whistles. But a really quick way to load or test your map or mod with just about any source engine. Because it doesn't have any combo box selections and such, it requires that the user already knows which command parameters to type in the textbox at the bottom of the utility, e.g. +map or -warp, depending on the source engine loaded.


=================================

Usage:

Load a Doom Source engine loation, eg: Zdoom.exe, DoomLegacy.exe, Gzdoom.exe, Zandronum.exe, etc.

Load an Iwad, eg Doom.wad, Doom2.wad, Freedoom1.wad etc.

Load a Pwad or pk3 file, if wanted.

Add any additional parameters at the bottom, eg: +map map01, -warp 01, -skill 3, -deathmatch, -host, etc.

Click Launch!