File List Exporter created by: Ron Goode aka Mr.Rocket 2025

File List Exporter is a really small utility to simply export the file names in a given directory to a .txt file called file_list.txt. This can come in handy if you have, for example, a bunch of images and you want to make an animation script for a project, where the outputted text file will end up with a list of all the image names, so you won't need to type them all out manually.


==============================================

Usage:

Click "Get Directory" to Load a directory/folder that you want to get a list of file names in.

Click "Export List" to create the txt file "file_list.txt" which will have a list of all the files in 
the chosen directory. The file_list.txt will be created in that directory by default. 

